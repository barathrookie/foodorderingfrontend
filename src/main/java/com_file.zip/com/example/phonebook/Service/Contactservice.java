package com.example.phonebook.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.phonebook.Repo.ContactsRepo;
import com.example.phonebook.models.Contacts;



@Service
public class Contactservice {
	
	@Autowired
	ContactsRepo contactrepo;
	
	public void addcontct(Contacts contact)
	{
		contactrepo.save(contact);
	}
	

}
