package com.example.phonebook.Controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.phonebook.Repo.ContactsRepo;
import com.example.phonebook.Repo.UserdetailRepo;
import com.example.phonebook.Repo.UserloginRepo;
import com.example.phonebook.Service.Contactservice;
import com.example.phonebook.Service.Userservice;
import com.example.phonebook.models.Contacts;
import com.example.phonebook.models.Userdetail;
import com.example.phonebook.models.Userlogin;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/demo")
@RequiredArgsConstructor
public class Apicontroller {

//    @Autowired
//    private Userservice userService;
//    @Autowired
//    private Contactservice contactservice;
//    @Autowired
//    private UserdetailRepo repo;
//    @Autowired
//    private ContactsRepo contactrepo2;
//    @Autowired
//    private UserloginRepo userRepo;
    
    @GetMapping("/get")
    public String geti()
    {
    	return "mukesh";
    }

//    @PostMapping("/post")
//    public ResponseEntity<String> saveUserDetails(@Validated @RequestBody Userdetail userDetails) {
//        userService.saveUserDetails(userDetails);
//        return ResponseEntity.ok("User details saved successfully");
//    }
//    @PostMapping("/addcontact")
//    public ResponseEntity<String> savecontact(@RequestBody Contacts contact)
//    {
//    	contactservice.addcontct(contact);
//    	return ResponseEntity.ok("Contact added Succsessfully");
//    }

}
