package com.example.phonebook.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.phonebook.models.Contacts;

public interface ContactsRepo extends JpaRepository<Contacts,Integer> {

}
